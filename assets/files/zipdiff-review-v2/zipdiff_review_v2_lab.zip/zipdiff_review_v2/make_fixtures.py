"""Generate four fixed, harmless text fixtures for a ZIP parser comparison."""

import io
import struct
import sys
import zipfile
from pathlib import Path

MARKER = b"MARKER_BLOCK"
SAFE = b"This is harmless classroom text.\n"
MARKED = b"MARKER_BLOCK\nThis is harmless marker text.\n"
GAP = b"LFH_STREAM_STOP".ljust(32, b"_")


def ordinary_zip(with_marker):
    buffer = io.BytesIO()
    entries = [("safe.txt", SAFE)]
    if with_marker:
        entries.append(("marker.txt", MARKED))
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_STORED) as archive:
        for name, data in entries:
            info = zipfile.ZipInfo(name, date_time=(2025, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    return buffer.getvalue()


def directory_records(raw):
    # This helper accepts only the small ZIP32 fixture created above.
    eocd = len(raw) - 22
    fields = struct.unpack_from("<4s4H2IH", raw, eocd)
    sig, disk, cd_disk, n_disk, n_total, cd_size, cd_start, comment = fields
    if (sig, disk, cd_disk, n_disk, n_total, comment) != (
        b"PK\x05\x06", 0, 0, 2, 2, 0
    ) or cd_start + cd_size != eocd:
        raise ValueError("Unexpected fixed fixture")
    records = []
    cursor = cd_start
    while cursor < eocd:
        if raw[cursor:cursor + 4] != b"PK\x01\x02":
            raise ValueError("CDH signature missing")
        n, x, c = struct.unpack_from("<HHH", raw, cursor + 28)
        length = 46 + n + x + c
        name = raw[cursor + 46:cursor + 46 + n].decode("ascii")
        record = raw[cursor:cursor + length]
        records.append((name, record))
        cursor += length
    if cursor != eocd or [name for name, _ in records] != ["safe.txt", "marker.txt"]:
        raise ValueError("Unexpected central directory entries")
    return cd_start, raw[eocd:], records


def remove_marker_cdh(raw):
    """C1 construction 1: leave marker LFH/data, remove its CDH."""
    cd_start, footer, records = directory_records(raw)
    directory = b"".join(record for name, record in records if name == "safe.txt")
    footer = bytearray(footer)
    struct.pack_into("<H", footer, 8, 1)               # entries on this disk
    struct.pack_into("<H", footer, 10, 1)              # total entries
    struct.pack_into("<I", footer, 12, len(directory)) # central directory size
    # EOCD +16 remains unchanged: the local-data area did not move.
    return raw[:cd_start] + directory + footer


def interrupt_lfh_stream(raw):
    """C1 construction 2: insert non-LFH bytes before marker's LFH."""
    cd_start, footer, records = directory_records(raw)
    marker_record = next(record for name, record in records if name == "marker.txt")
    insertion = struct.unpack_from("<I", marker_record, 42)[0]
    if raw[insertion:insertion + 4] != b"PK\x03\x04":
        raise ValueError("marker LFH not found")
    directory = bytearray()
    for _, record in records:
        record = bytearray(record)
        local_offset = struct.unpack_from("<I", record, 42)[0]
        if local_offset >= insertion:
            struct.pack_into("<I", record, 42, local_offset + len(GAP))
        directory.extend(record)
    footer = bytearray(footer)
    struct.pack_into("<I", footer, 16, cd_start + len(GAP))
    # Counts (+8/+10) and directory size (+12) remain unchanged.
    return raw[:insertion] + GAP + raw[insertion:cd_start] + directory + footer


def make_fixtures(destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    normal = ordinary_zip(True)
    fixtures = {
        "safe_control": ordinary_zip(False),
        "normal_marker_control": normal,
        "c1_missing_cdh": remove_marker_cdh(normal),
        "c1_interrupted_stream": interrupt_lfh_stream(normal),
    }
    for name, data in fixtures.items():
        (destination / (name + ".zip")).write_bytes(data)
    return fixtures


if __name__ == "__main__":
    destination = Path(sys.argv[1]) if len(sys.argv) == 2 else Path("fixtures")
    for name, data in make_fixtures(destination).items():
        print(name + ".zip", len(data), "bytes")
