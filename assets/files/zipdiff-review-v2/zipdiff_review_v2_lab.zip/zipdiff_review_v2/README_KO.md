# ZipDiff C1 양방향 로컬 실험

이 패키지는 무해한 텍스트 두 개로 ZIP 파서의 읽기 범위를 비교한다. 논문 §5.2.3 C1의 첫 번째와 두 번째 구성에 대응하는 작은 실험이다.

| 시나리오 | 검사 역할 | 후단 추출 역할 | 관심 입력 |
| --- | --- | --- | --- |
| A | Python zipfile.ZipFile이 읽은 파일의 표시 문자열 검사 | Java ZipInputStream | c1_missing_cdh.zip |
| B | Java JarInputStream이 읽은 파일의 표시 문자열 검사 | JDK ZipFile | c1_interrupted_stream.zip |

검사 역할에만 `MARKER_BLOCK` 문자열 규칙을 적용한다. 후단에는 PASS/BLOCK 판정이 없다. 검사에서 차단되는 정상 대조군도 파서의 동작을 비교하기 위해 후단을 독립 실행한다. 이는 실제 서비스가 차단한 입력을 전달했다는 뜻이 아니다.

## 준비와 실행

검증 환경은 Linux x86-64, Python 3.12.14, OpenJDK 21.0.13이다. Python 표준 라이브러리만 사용하고 Java는 소스 파일 실행 기능을 사용한다. Python 3.10 이상과 JDK 21을 준비한다.

Ubuntu에서는 다음과 같이 설치한다.

```bash
sudo apt update
sudo apt install -y python3 openjdk-21-jdk-headless unzip
```

이 패키지를 해제한 후 실행한다.

```bash
cd zipdiff_review_v2
python3 run_lab.py
```

Windows에서 Python과 JDK 21이 준비돼 있다면 같은 폴더에서 다음과 같이 실행한다.

```powershell
py -3 run_lab.py
```

이번에 제공하는 관측 로그는 Linux에서 얻은 것이다. 각자의 실행 환경은 새 실행 결과의 `results.json`에 기록된다. 실험 자체는 네트워크 연결이나 서버 구동을 사용하지 않는다.

## 기대 관측

| 입력 | Python 중앙 디렉터리 | Java ZipInputStream | Java JarInputStream | JDK ZipFile |
| --- | --- | --- | --- | --- |
| safe_control | safe | safe | safe | safe |
| normal_marker_control | safe + marker | safe + marker | safe + marker | safe + marker |
| c1_missing_cdh | safe | safe + marker | safe + marker | safe |
| c1_interrupted_stream | safe + marker | safe | safe | safe + marker |

각 이름은 `safe.txt`, `marker.txt`를 줄여 표시했다. 성공하면 마지막에 `All expected observations matched: True`가 출력된다. 관심 사례에서는 검사 결과가 PASS이고 후단에 marker가 있으며 출력 트리 해시가 다르다.

`marker_reachable_after_pass`는 이 세 조건 중 검사 PASS와 후단 표시 파일 관측을 연결한 실험용 지표다. 실제 제품의 서명 검증이나 파일 실행을 뜻하지 않는다.

## 파일 구성

- `make_fixtures.py`: 고정된 네 ZIP을 생성한다. CDH 삭제와 EOCD 수정, LFH 사이 바이트 삽입과 오프셋 보정을 모두 포함한다.
- `ArchiveReader.java`: Java의 세 API로 실제 파일을 추출한다. 엔트리 내용을 끝까지 읽고 CRC를 확인한다. 파일명과 크기를 고정된 실험 범위로 제한한다.
- `run_lab.py`: Python과 Java의 읽기를 각각 실행하고 입력 SHA-256, 출력 파일별 SHA-256, 출력 트리 해시, 종료 코드, stderr 및 검사 역할의 판정을 기록한다.
- `observed_run`: 이 패키지 작성 시 실제 실행한 참고 기록이다. 각자의 실행 결과와 구분한다.
- `runs/run-...`: 직접 실행할 때 새로 생성되는 결과 디렉터리다. 기존 실행 결과는 덮어쓰지 않는다.

새 실행 폴더에는 `archives`, 각 입력의 파서별 추출 디렉터리와 stdout/stderr, `summary.txt`, `results.json`이 들어간다. 참고 기록에는 검증한 ZIP의 실제 필드 값을 기록한 `structure.json`과 실행 코드의 해시인 `code_sha256.json`도 포함했다.

생성기만 실행하려면 다음 명령을 사용한다. 대상 디렉터리가 이미 있으면 중단한다.

```bash
python3 make_fixtures.py fixtures
```

## 결과 해석

입력 ZIP의 해시는 같은 입력을 전달했는지 확인한다. 출력 트리의 해시는 경로·크기·내용 해시로 구성된 정렬 JSON을 비교한다. 시간과 권한은 포함하지 않는다. 임의의 파일 시스템 객체를 위한 완전한 정규화 알고리즘은 아니다.

후단을 독립 측정했으므로 정상 표시 파일 대조군에서는 검사 BLOCK과 후단 marker 추출 관측이 동시에 나타날 수 있다. 실제 처리 경로에 전달될 수 있는 관심 사례는 검사 PASS와 후단 marker 관측이 동시에 나온 경우다.

실험 B의 JDK ZipFile은 Spring Boot의 ZipContent와 다른 구현이다. 모든 입력은 서명 없는 텍스트 ZIP이고 JarInputStream은 verify=false로 생성한다. 여기서 확인하는 것은 Spring Boot 사례와 같은 검사·사용 방향의 파서 차이다. CVE-2024-38807의 서명 위조 재현을 주장하지 않는다.

## 참고 자료

- [논문 원문](https://www.jianjunchen.com/p/zipdiff.USESEC25.pdf): §5.2.3 C1, §6.4.
- [저자 공개 아티팩트](https://github.com/ouuan/ZipDiff): 이 패키지는 저자의 전체 퍼저를 실행한 결과가 아니라 논문 구성법을 참고해 별도로 작성한 최소 실험이다.
- [PKWARE APPNOTE](https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT): ZIP 구조와 오프셋.
- [Spring 공식 권고문](https://spring.io/security/cve-2024-38807/): 영향 조건과 수정 버전.
- [JarInputStream 공식 문서](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/jar/JarInputStream.html): manifest와 서명 검증 조건.
