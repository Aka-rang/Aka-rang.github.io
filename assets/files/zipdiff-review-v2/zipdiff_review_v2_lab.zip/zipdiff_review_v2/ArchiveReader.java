import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Set;
import java.util.jar.JarInputStream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

public class ArchiveReader {
    static final Set<String> ALLOWED = Set.of("safe.txt", "marker.txt");
    static final List<String> names = new ArrayList<>();
    static final Set<String> seen = new HashSet<>();

    static void extract(ZipEntry entry, InputStream input, Path output) throws Exception {
        String name = entry.getName();
        if (!ALLOWED.contains(name) || entry.isDirectory() || !seen.add(name)) {
            throw new IOException("Unexpected fixed-fixture entry: " + name);
        }
        byte[] content = input.readNBytes(4097);
        if (content.length > 4096) throw new IOException("Entry exceeds lab size limit");
        CRC32 crc = new CRC32();
        crc.update(content);
        if (entry.getCrc() != crc.getValue()) throw new IOException("CRC mismatch");
        Files.write(output.resolve(name), content);
        names.add(name);
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("MODE ZIP OUTPUT");
        String mode = args[0];
        Path source = Path.of(args[1]);
        Path output = Path.of(args[2]);
        if (Files.size(source) > 65536) throw new IOException("Archive exceeds lab size limit");
        byte[] raw = Files.readAllBytes(source);
        String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(raw));
        Files.createDirectory(output);
        if (mode.equals("central")) {
            // ZipFile needs a file. Read a private copy of the exact hashed bytes.
            Path snapshot = Files.createTempFile("zipdiff-reader-", ".zip");
            try {
                Files.write(snapshot, raw);
                try (ZipFile archive = new ZipFile(snapshot.toFile())) {
                    var entries = archive.entries();
                    while (entries.hasMoreElements()) {
                        ZipEntry entry = entries.nextElement();
                        try (InputStream input = archive.getInputStream(entry)) {
                            extract(entry, input, output);
                        }
                    }
                }
                if (!Arrays.equals(raw, Files.readAllBytes(snapshot))) {
                    throw new IOException("Reader snapshot changed");
                }
            } finally {
                Files.deleteIfExists(snapshot);
            }
        } else {
            ZipInputStream stream;
            if (mode.equals("zip-stream")) {
                stream = new ZipInputStream(new ByteArrayInputStream(raw));
            } else if (mode.equals("jar-stream")) {
                // Fixed unsigned text fixtures: no signature verification is tested.
                stream = new JarInputStream(new ByteArrayInputStream(raw), false);
            } else {
                throw new IllegalArgumentException("Unknown mode");
            }
            try (stream) {
                ZipEntry entry;
                while ((entry = stream.getNextEntry()) != null) {
                    extract(entry, stream, output);
                    stream.closeEntry();
                }
            }
        }
        String entries = names.stream().map(n -> "\"" + n + "\"")
            .collect(java.util.stream.Collectors.joining(",", "[", "]"));
        System.out.println("{\"input_sha256\":\"" + hash + "\",\"entries\":" + entries + "}");
    }
}
