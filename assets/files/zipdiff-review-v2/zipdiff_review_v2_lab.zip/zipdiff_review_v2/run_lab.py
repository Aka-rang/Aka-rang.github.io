"""Compare fixed text fixtures; keep scanner decisions separate from consumers."""

import argparse
import hashlib
import io
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

from make_fixtures import MARKER, make_fixtures

HERE = Path(__file__).resolve().parent
ALLOWED = {"safe.txt", "marker.txt"}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def python_reader(archive_path, output):
    raw = archive_path.read_bytes()
    if len(raw) > 65536:
        raise ValueError("Archive exceeds lab size limit")
    output.mkdir()
    names = []
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        for entry in archive.infolist():
            if entry.filename not in ALLOWED or entry.filename in names or entry.file_size > 4096:
                raise ValueError("Unexpected fixed-fixture entry")
            content = archive.read(entry)
            (output / entry.filename).write_bytes(content)
            names.append(entry.filename)
    print(json.dumps({"input_sha256": sha256(raw), "entries": names}))


def output_manifest(output):
    files = []
    for path in sorted(output.iterdir()):
        if not path.is_file() or path.name not in ALLOWED:
            raise ValueError("Unexpected extracted object")
        content = path.read_bytes()
        files.append({"path": path.name, "size": len(content), "sha256": sha256(content)})
    encoded = json.dumps(files, sort_keys=True, separators=(",", ":")).encode("ascii")
    return {"files": files, "tree_sha256": sha256(encoded)}


def read_archive(command, output, logs, label):
    try:
        proc = subprocess.run(command, capture_output=True, text=True, timeout=90)
    except subprocess.TimeoutExpired:
        return {"status": "ERROR", "returncode": None, "error": "Reader exceeded 90 seconds"}
    (logs / (label + ".stdout.txt")).write_text(proc.stdout, encoding="utf-8")
    (logs / (label + ".stderr.txt")).write_text(proc.stderr, encoding="utf-8")
    result = {"returncode": proc.returncode, "stderr": proc.stderr, "status": "ERROR"}
    if proc.returncode == 0:
        try:
            result.update(json.loads(proc.stdout))
            result.update(output_manifest(output))
            result["status"] = "OK"
        except (ValueError, OSError) as error:
            result["error"] = str(error)
    return result


def scanner_decision(reader, output):
    if reader["status"] != "OK":
        return "ERROR"
    return "BLOCK" if any(MARKER in p.read_bytes() for p in output.iterdir()) else "PASS"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs-dir", type=Path, default=HERE / "runs")
    parser.add_argument("--python-reader", nargs=2, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.python_reader:
        python_reader(*map(Path, args.python_reader))
        return 0
    java = shutil.which("java")
    if not java:
        parser.error("Install a JDK 21 and make java available on PATH.")
    version = subprocess.run([java, "-version"], capture_output=True, text=True, timeout=15)
    args.runs_dir.mkdir(parents=True, exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix="run-", dir=args.runs_dir)).resolve()
    fixtures = make_fixtures(root / "archives")
    reader_names = ("python-central", "java-zip-stream", "java-jar-stream", "java-central")
    expected_lists = {
        "safe_control": [["safe.txt"]] * 4,
        "normal_marker_control": [["safe.txt", "marker.txt"]] * 4,
        "c1_missing_cdh": [["safe.txt"], ["safe.txt", "marker.txt"], ["safe.txt", "marker.txt"], ["safe.txt"]],
        "c1_interrupted_stream": [["safe.txt", "marker.txt"], ["safe.txt"], ["safe.txt"], ["safe.txt", "marker.txt"]],
    }
    report = {
        "schema_version": 2,
        "scope": "Fixed unsigned text, C1 parser visibility; no actual product or signature-verification reproduction",
        "environment": {"python": sys.version, "platform": platform.platform(),
                        "java": (version.stdout + version.stderr).strip()},
        "scanner_rule": "BLOCK if MARKER_BLOCK appears in a file read by the designated scanner; ERROR on reader failure",
        "consumer_policy": "None: consumer extraction is measured independently, including blocked controls",
        "manifest_definition": "SHA256 of compact sorted-key JSON of path-sorted path/size/content-SHA256 records",
        "cases": [],
    }
    lines = ["ZipDiff C1 bidirectional lab", "Python: " + platform.python_version(),
             "Java: " + report["environment"]["java"].splitlines()[0], ""]
    matched = True
    for name, raw in fixtures.items():
        case_dir = root / name
        case_dir.mkdir()
        archive = root / "archives" / (name + ".zip")
        readers = {}
        checkpoints = [sha256(archive.read_bytes())]
        for label in reader_names:
            output = case_dir / label
            if label == "python-central":
                command = [sys.executable, str(HERE / "run_lab.py"), "--python-reader", str(archive), str(output)]
            else:
                command = [java, str(HERE / "ArchiveReader.java"), label.removeprefix("java-"), str(archive), str(output)]
            readers[label] = read_archive(command, output, case_dir, label)
            checkpoints.append(sha256(archive.read_bytes()))
        successful = all(r["status"] == "OK" for r in readers.values())
        same_input = successful and all(h == sha256(raw) for h in checkpoints) and all(r.get("input_sha256") == sha256(raw) for r in readers.values())
        row_matches = successful and same_input and [readers[k].get("entries") for k in reader_names] == expected_lists[name]
        scenarios = {}
        for direction, scanner, consumer in (
            ("A_central_to_stream", "python-central", "java-zip-stream"),
            ("B_stream_to_central", "java-jar-stream", "java-central"),
        ):
            decision = scanner_decision(readers[scanner], case_dir / scanner)
            consumer_ok = readers[consumer]["status"] == "OK"
            consumer_names = readers[consumer].get("entries", [])
            equal = successful and readers[scanner]["tree_sha256"] == readers[consumer]["tree_sha256"]
            scenarios[direction] = {
                "scanner": scanner, "scanner_decision": decision, "consumer": consumer,
                "consumer_entries_independent_probe": consumer_names,
                "consumer_marker_extracted": consumer_ok and "marker.txt" in consumer_names,
                "output_trees_equal": equal,
                "marker_reachable_after_pass": bool(decision == "PASS" and consumer_ok and "marker.txt" in consumer_names),
                "consistency_gate": "PASS" if same_input and successful and equal and decision == "PASS" else "BLOCK",
            }
        case = {"name": name, "input_sha256": sha256(raw), "input_size": len(raw),
                "all_readers_successful": successful, "input_hashes_equal_and_unchanged": same_input,
                "input_hash_checkpoints": checkpoints, "readers": readers, "scenarios": scenarios,
                "matches_expected_observation": bool(row_matches)}
        report["cases"].append(case)
        matched = matched and row_matches
        lines.extend(["[" + name + "]", "  input_sha256=" + sha256(raw),
                      "  input_same_and_unchanged=" + str(same_input)])
        for label in reader_names:
            r = readers[label]
            lines.append("  " + label + ": exit=" + str(r["returncode"]) + " entries=" + str(r.get("entries")))
        for direction, s in scenarios.items():
            lines.append("  " + direction + ": scanner=" + s["scanner_decision"]
                         + " consumer_marker_extracted=" + str(s["consumer_marker_extracted"])
                         + " trees_equal=" + str(s["output_trees_equal"])
                         + " marker_reachable_after_pass=" + str(s["marker_reachable_after_pass"]))
        lines.append("")
    report["all_expected_observations_matched"] = bool(matched)
    lines.extend(["All expected observations matched: " + str(bool(matched)), "Output directory: " + str(root)])
    (root / "results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (root / "summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0 if matched else 1


if __name__ == "__main__":
    raise SystemExit(main())
